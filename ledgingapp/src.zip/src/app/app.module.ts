import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { HeadComponent } from './head.component';
import { LeftMenuComponent } from './leftmenu.component';
import { MainPanelComponent } from './mainpanel.component';
import { AccountReportComponent } from './accountreport.component';

import { AppRoutingModule }       from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent, HeadComponent, LeftMenuComponent, MainPanelComponent, AccountReportComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
