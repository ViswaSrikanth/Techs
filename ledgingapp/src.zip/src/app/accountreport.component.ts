import { Component } from '@angular/core';

@Component({
  selector: 'main-panel',
  templateUrl: './accountreport.component.html',
  styleUrls: ['./accountreport.component.css']
})
export class AccountReportComponent {
  subtitle = "Account Report"
}
