import { Component } from '@angular/core';

@Component({
  selector: 'main-panel',
  templateUrl: './mainpanel.component.html',
  styleUrls: ['./mainpanel.component.css']
})
export class MainPanelComponent {
  subtitle = "Dashboard"
}
