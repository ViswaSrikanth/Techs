import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent }           from './app.component';
import { LeftMenuComponent }  from './leftmenu.component';
import { MainPanelComponent }    from './mainpanel.component';
import { AccountReportComponent }    from './accountreport.component';

//import { AuthGuard }                from '../auth-guard.service';

const appRoutes: Routes = [
  {
    path: '',
    component: AppComponent,
    //canActivate: [AuthGuard],
    children: [
      {
        path: '',
        //canActivateChild: [AuthGuard],
        children: [
          { path: 'home', component: MainPanelComponent },
          { path: 'accountreport', component: AccountReportComponent },
          { path: '', component: MainPanelComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}
